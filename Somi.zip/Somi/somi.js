function Evento (foto)
{
    document.getElementById("icone").src=foto;
}